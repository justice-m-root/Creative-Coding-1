onEvent("Start", "click", function( ) {
  playSound("assets/category_app/app_button_5.mp3", false);
  setScreen("Q1");
});
onEvent("True", "click", function( ) {
  playSound("assets/category_bell/vibrant_game_correct_answer_1.mp3", false);
  setScreen("A1");
});
onEvent("False", "click", function( ) {
  setScreen("A1");
  playSound("assets/category_music/game_over_2.mp3", false);
});
onEvent("Continue1", "click", function( ) {
  setScreen("Q2");
  playSound("assets/category_app/app_button_5.mp3", false);
});
onEvent("True2", "click", function( ) {
  setScreen("A2");
  playSound("assets/category_music/game_over_2.mp3", false);
});
onEvent("False2", "click", function( ) {
  setScreen("A2");
  playSound("assets/category_bell/vibrant_game_correct_answer_1.mp3", false);
});
onEvent("Continue2", "click", function( ) {
  setScreen("Q3");
  playSound("assets/category_app/app_button_5.mp3", false);
});
onEvent("True3", "click", function( ) {
  setScreen("A3");
  playSound("assets/category_bell/vibrant_game_correct_answer_1.mp3", false);
});
onEvent("Continue4", "click", function( ) {
  setScreen("Final");
  playSound("assets/category_app/app_button_5.mp3", false);
});
onEvent("False3", "click", function( ) {
  playSound("assets/category_music/game_over_2.mp3", false);
  setScreen("A3");
});
onEvent("Continue3", "click", function( ) {
  setScreen("Q4");
  playSound("assets/category_app/app_button_5.mp3", false);
});
onEvent("True4", "click", function( ) {
  setScreen("A4");
  playSound("assets/category_bell/vibrant_game_correct_answer_1.mp3", false);
});
onEvent("False4", "click", function( ) {
  setScreen("A4");
  playSound("assets/category_music/game_over_2.mp3", false);
});
onEvent("Final", "click", function( ) {
  playSound("assets/category_background/fantasy.mp3", false);
});
